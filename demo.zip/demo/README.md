# demo
A RESTful demo including a POM, an EAR, an EJB and a WAR projects.