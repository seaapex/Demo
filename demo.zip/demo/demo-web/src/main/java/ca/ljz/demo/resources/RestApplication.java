package ca.ljz.demo.resources;

@javax.ws.rs.ApplicationPath("rest")
public class RestApplication extends javax.ws.rs.core.Application {
}