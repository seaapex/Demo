package ca.sait.xml.adapters;

import java.text.SimpleDateFormat;
import javax.xml.bind.annotation.adapters.XmlAdapter;

import java.util.Date;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class TimeAdapter extends XmlAdapter<String, Date> {

    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private final Lock lock = new ReentrantLock();

    @Override
    public Date unmarshal(String v) throws Exception {
        try {
            lock.lock();
            return sdf.parse(v);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public String marshal(Date v) throws Exception {
        try {
            lock.lock();
            return sdf.format(v);
        } finally {
            lock.unlock();
        }
    }

}
