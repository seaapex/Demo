package ca.sait.ejbs;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import ca.sait.entities.Note;

/**
 * Session Bean implementation class NoteEJB
 */
@Stateless
public class NoteEJB extends BaseEJB<Integer, Note> {

    /**
     *
     */
    private static final long serialVersionUID = 8476159698976290856L;

    @EJB
    UserEJB userEJB;

    @Override
    protected Class<Note> getEntityType() {
        return Note.class;
    }

    @Override
    public List<Note> findAll() {
        return null;
    }
}
