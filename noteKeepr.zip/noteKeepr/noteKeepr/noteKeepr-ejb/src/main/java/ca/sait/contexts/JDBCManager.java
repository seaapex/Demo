package ca.sait.contexts;

import java.sql.Connection;
import java.sql.SQLException;

import javax.annotation.PostConstruct;
import javax.inject.Singleton;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import ca.sait.annotations.JDBCContext;

@Singleton
@JDBCContext
public class JDBCManager {

	private static DataSource dS = null;

	@PostConstruct
	private void init(){
		try {
			InitialContext ic = new InitialContext();
			dS = (DataSource) ic.lookup("jdbc/NotesDB");
		} catch (NamingException e) {
			throw new RuntimeException(e);
		}
	}

	public Connection getConnection() throws SQLException {
		return dS.getConnection();
	}
}
