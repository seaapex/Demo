angular.module('noteKeepr')

.controller("loginCtrl",["$scope","$cookieStore","$location","$window","sendRequest", function($scope, $cookieStore, $location,$window, sendRequest){

    $scope.login = function(){
        sendRequest.send(
			'GET',
			'http://localhost:8080/noteKeepr-web/rest/user/'+$scope.username+'/self',
			'application/json',
			$scope.username,
			$scope.password,
			null,
			function (result) {
				console.log(result.data);
				$cookieStore.put("username",$scope.username);
				$cookieStore.put("password",$scope.password);
				
				var user = result.data;
				var isAdmin = false;
				
				result.data.roles.forEach(function(role){
					console.log(role.rolename);
					if(role.rolename === "admin")
						isAdmin = true;
				});
				
				$cookieStore.put("isAdmin",isAdmin);
				
				if(isAdmin){
					$location.path("admin");
					$window.location.reload();
				}
				else{
					$location.path("test");
					$window.location.reload();
				}
            },
			function (error) {
                $scope.errMsg = "invalid username or password"
            }
		)};
}]);