//angular.module("registerModule",[])
//
//.controller("registerCtrl",["$scope", function($scope){
//    
//    $scope.user = {};
//    
//    $scope.user.username = "";
//    $scope.user.password = "";
//    $scope.user.firstname = "";
//    $scope.user.lastname = "";
//    $scope.user.email = "";
//    $scope.user.phonenumber = "";
//    $scope.user.gender = "";
//    
//    $scope.time2 = function(){
//        $scope.number *= 2;
//    }
//}]);