angular.module('noteKeepr')

.controller("signupCtrl",["$scope","$cookieStore","$location","sendRequest", function($scope, $cookieStore, $location, sendRequest){
	
	$scope.isCreation = true;
	
	$scope.username = "";
	$scope.password = "";
	$scope.firstname = "";
	$scope.lastname = "";
	$scope.email = "";
	$scope.phonenumber = "";
	$scope.gender = "";
	
	
    var getUsers = function(){
        sendRequest.send(
			'GET',
			'http://localhost:8080/noteKeepr-web/rest/user',
			'application/json',
			$cookieStore.get("username"),
			$cookieStore.get("password"),
			null,
			function (result) {
				console.log(result.data);
				result.data.forEach(function(user){
					user.isAdmin = false;
					user.roles.forEach(function(role){
						if(role.rolename === "admin"){
							user.isAdmin = true;
						}
					});
				});
				$scope.users = result.data;
            },
			function (error) {
                $scope.errMsg = "You don't have admin privilege";
            }
		)};
	
	getUsers();
	
	$scope.promoteUser = function(username){
        sendRequest.send(
			'PUT',
			'http://localhost:8080/noteKeepr-web/rest/user/'+username+'/promote',
			'application/json',
			$cookieStore.get("username"),
			$cookieStore.get("password"),
			null,
			function (result) {
				getUsers();
            },
			function (error) {
                $scope.errMsg = "You don't have admin privilege";
            }
		)};
	
	$scope.demoteUser = function(username){
        sendRequest.send(
			'PUT',
			'http://localhost:8080/noteKeepr-web/rest/user/'+username+'/demote',
			'application/json',
			$cookieStore.get("username"),
			$cookieStore.get("password"),
			null,
			function (result) {
				getUsers();
            },
			function (error) {
				if(error.status===406){
					console.log("You can't demote yourself");
					$scope.errMsg = "You can't demote yourself";
				}else{
					$scope.errMsg = "You don't have admin privilege";
				}
            }
		)};
	
	$scope.editUser = function(username){
		
		$scope.isCreation = false;
		
		$scope.users.forEach(function(user){
			if(username === user.username){
				$scope.username = user.username;
				$scope.firstname = user.firstname;
				$scope.lastname = user.lastname;
				$scope.email = user.email;
				$scope.phonenumber = user.phonenumber;
				$scope.gender = user.gender;
			}
		});
	};
	
	$scope.saveUser = function(username){
		
        sendRequest.send(
			'PUT',
			'http://localhost:8080/noteKeepr-web/rest/user/'+$scope.username,
			'application/json',
			$cookieStore.get("username"),
			$cookieStore.get("password"),
			{
				username: $scope.username,
				password: $scope.password,
				firstname: $scope.firstname,
				lastname: $scope.lastname,
				email: $scope.email,
				phonenumber: $scope.phonenumber,
				gender: $scope.gender
			},
			function (result) {
				$scope.isCreation = true;
				if($scope.username===$cookieStore.get("username") && $scope.password)
					$cookieStore.put("password",$scope.password);
				getUsers();
				
				$scope.username = "";
				$scope.password = "";
				$scope.firstname = "";
				$scope.lastname = "";
				$scope.email = "";
				$scope.phonenumber = "";
				$scope.gender = "";
            },
			function (error) {
				if(error.status===406){
					console.log("You can't delete yourself");
					$scope.errMsg = "You can't delete yourself";
				}else{
					$scope.errMsg = "You don't have admin privilege";
				}
            }
		)};
	
	$scope.deleteUser = function(username){
        sendRequest.send(
			'DELETE',
			'http://localhost:8080/noteKeepr-web/rest/user/'+username,
			'application/json',
			$cookieStore.get("username"),
			$cookieStore.get("password"),
			null,
			function (result) {
				getUsers();
            },
			function (error) {
				if(error.status===406){
					console.log("You can't delete yourself");
					$scope.errMsg = "You can't delete yourself";
				}else{
					$scope.errMsg = "You don't have admin privilege";
				}
            }
		)};
	
	$scope.createUser = function(){

		sendRequest.send(
			'POST',
			'http://localhost:8080/noteKeepr-web/rest/user',
			'application/json',
			$cookieStore.get("username"),
			$cookieStore.get("password"),
			{
				username: $scope.username,
				password: $scope.password,
				firstname: $scope.firstname,
				lastname: $scope.lastname,
				email: $scope.email,
				phonenumber: $scope.phonenumber,
				gender: $scope.gender
			},
			function (result) {
				getUsers();
            },
			function (error) {
				if(error.status===406){
					console.log("You can't delete yourself");
					$scope.errMsg = "You can't delete yourself";
				}else{
					$scope.errMsg = "You don't have admin privilege";
				}
            }
		)};
	
}]);