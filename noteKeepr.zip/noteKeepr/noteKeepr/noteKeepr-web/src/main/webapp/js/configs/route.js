angular.module('noteKeepr')
	
.config(function ($routeProvider) {
    $routeProvider
            .when("/", {
                templateUrl: "view/login.html",
                controller: "loginCtrl"
            })

            .when("/admin", {
                templateUrl: "view/admin.html",
                controller: "adminCtrl"
            })
	
            .when("/test", {
                templateUrl: "view/test.html",
                controller: "loginCtrl"
            })
	
            .otherwise({
                redirectTo: "/"
            })
});