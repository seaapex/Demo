angular.module('noteKeepr')

.controller("adminCtrl",["$scope","$cookieStore","$location","sendRequest", function($scope, $cookieStore, $location, sendRequest){

	$scope.aaa="adfadf";
	
	
    var getUsers = function(){
        sendRequest.send(
			'GET',
			'http://localhost:8080/noteKeepr-web/rest/user',
			'application/json',
			$cookieStore.get("username"),
			$cookieStore.get("password"),
			null,
			function (result) {
				console.log(result.data);
				$scope.users = result.data;
            },
			function (error) {
                $scope.errMsg = "You don't have admin privilege";
            }
		)};
	
	getUsers();
	
}]);