package ca.sait.resources;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import ca.sait.annotations.Auth;
import ca.sait.annotations.AuthContext;
import ca.sait.contexts.CallerManager;
import ca.sait.entities.User;
import ca.sait.exceptions.ValidationException;
import ca.sait.services.EmailService;
import ca.sait.services.RegistrationService;
import ca.sait.services.UserService;
import ca.sait.unwrappers.AbstractExceptionUnwrapper;
import ca.sait.xml.Message;
import java.net.URI;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.UriBuilder;

@Path("user")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Stateless
public class UserResource {

    private static final Logger logger = Logger.getLogger(UserResource.class.getName());

    @EJB
    private UserService us;

    @EJB
    private RegistrationService rs;

    @EJB
    private EmailService es;

    @Inject
    @AuthContext
    private CallerManager ac;

    @Inject
    private HttpServletRequest request;

    @GET
    @Auth("admin")
    public Response findAll() {
        logger.log(Level.INFO, "findAll");

        logger.log(Level.INFO, ac.getCallerPrincipal());

        logger.log(Level.INFO, us.findAllUsers().size() + " users are returned");
        GenericEntity<List<User>> list = new GenericEntity<List<User>>(us.findAllUsers()) {
        };

        return Response.status(Status.OK).entity(list).build();
    }

    @GET
    @Path("{username}")
    @Auth("admin")
    public Response findByUsername(@PathParam("username") String username) {
        User user = us.findUserByUsername(username);
        return Response.status(Status.OK).entity(user).build();
    }

    @GET
    @Path("{username}/self")
    @Auth({"admin", "user"})
    public Response selfReflect(@PathParam("username") String username) {
        User user = us.findUserByUsername(ac.getCallerPrincipal());
        return Response.status(Status.OK).entity(user).build();
    }

    @GET
    @Path("{input}/search")
    @Auth({"admin", "user"})
    public Response searchUser(@PathParam("input") String input) {
        List<User> found = us.searchUserByUsernameOrEmail(ac.getCallerPrincipal(), input);
        GenericEntity<List<User>> list = new GenericEntity<List<User>>(found) {
        };

        return Response.status(Status.OK).entity(list).build();
    }

    @POST
    @Auth({"admin"})
    public Response registerUser(User user) {
        logger.log(Level.INFO, "registerUser");
        try {
            us.createUser(user.getUsername(), user.getPassword(), user.getEmail(), user.getFirstname(),
                    user.getLastname(), user.getPhonenumber(), user.getGender());
            return Response.status(Status.CREATED).build();
        } catch (Throwable e) {
            logger.log(Level.INFO, "handling exception");

            ValidationException ex = new AbstractExceptionUnwrapper<ValidationException>() {
            }.unwrap(e);

            if (ex != null) {
                Message msgs = new Message();
                msgs.setMessages(ex.getMessages());
                return Response.status(Status.NOT_ACCEPTABLE).entity(msgs).build();
            }

            logger.log(Level.INFO, "unhandled exception");
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GET
    @Path("{username}/forgot")
    public Response forgotPassword(@PathParam("username") String username) {
        User user = us.findUserByUsername(username);

        if (user == null) {
            return Response.status(Status.NOT_FOUND).build();
        }

        HttpSession session = request.getSession();

        String uuid = UUID.randomUUID().toString();
        session.setAttribute(uuid, username);

        es.sendEmail(user.getEmail(), "Forgot Password", "Please click on or paste the following URL to your browser: http://localhost:8080/noteKeepr-web/rest/user/" + uuid + "/password");

        return Response.status(Status.OK).build();
    }

    @GET
    @Path("{uuid}/password")
    public Response password(@PathParam("uuid") String uuid) {
        HttpSession session = request.getSession();
        Object obj = session.getAttribute(uuid);

        if (obj != null) {
            URI uri = UriBuilder.fromUri("http://localhost:8080/noteKeepr-web/#/password/" + uuid).build();
            return Response.temporaryRedirect(uri).build();
        }

        return Response.status(Status.UNAUTHORIZED).build();
    }

    @PUT
    @Path("{uuid}/reset")
    public Response resetPassword(@PathParam("uuid") String uuid, User user) {
        System.out.println("ca.sait.resources.UserResource.resetPassword()");

        if (user == null || user.getPassword() == null || user.getPassword().isEmpty()) {
            return Response.status(Status.NOT_ACCEPTABLE).build();
        }

        HttpSession session = request.getSession();
        Object obj = session.getAttribute(uuid);

        if (obj != null) {
            System.out.println("ca.sait.resources.UserResource.resetPassword():uuid matches");
            User u = us.findUserByUsername(obj.toString());
            u.setPassword(user.getPassword());
            us.editUser(u.getUsername(), u.getPassword(), u.getEmail(), u.getFirstname(), u.getLastname(), u.getPhonenumber(), u.getGender());

            session.invalidate();

            return Response.status(Status.OK).build();
        }

        return Response.status(Status.UNAUTHORIZED).build();
    }

    @POST
    @Path("{username}")
    public Response selfRegister(User user) {
        logger.log(Level.INFO, "selfRegister");

        HttpSession session = request.getSession();

        logger.log(Level.INFO, "JSESSION_ID:" + session.getId());

        logger.log(Level.INFO, "Segister Service:" + rs);

        logger.log(Level.INFO, "Username:" + user.getUsername());
        logger.log(Level.INFO, "Password:" + user.getPassword());

        Message msg = rs.holdUser(user.getUsername(), user.getPassword(), user.getEmail(), user.getFirstname(), user.getLastname(), user.getPhonenumber(), user.getGender());

        if (msg == null) {
            session.setAttribute(rs.getUUID(), rs);
            es.sendEmail(user.getEmail(), "Please Activate Account", "Please click on or copy this url to your browser: http://localhost:8080/noteKeepr-web/rest/user/" + rs.getUUID() + "/confirm");
            return Response.status(Status.OK).build();
        } else {
            return Response.status(Status.NOT_ACCEPTABLE).entity(msg).build();
        }

    }

    @GET
    @Path("{uuid}/confirm")
    public Response registerConfirm(@PathParam("uuid") String uuid) {
        logger.log(Level.INFO, "registerConfirm");
        try {
            HttpSession session = request.getSession();
            logger.log(Level.INFO, "JSESSION_ID:" + session.getId());
            Object obj = session.getAttribute(uuid);

            if (obj != null && obj instanceof RegistrationService) {
                RegistrationService reg = (RegistrationService) obj;
                User user = us.findUserByUsername(reg.getUsername());
                us.editUser(user.getUsername(), reg.getPassword(), user.getEmail(), user.getFirstname(), user.getLastname(), user.getPhonenumber(), user.getGender());
                session.invalidate();

                es.sendEmail(user.getEmail(), "Account Activated", "Hi " + user.getFirstname() + ", your account is now activated!");

                URI uri = UriBuilder.fromUri("http://localhost:8080/noteKeepr-web/").build();
                return Response.temporaryRedirect(uri).build();
            } else {
                return Response.status(Status.UNAUTHORIZED).build();
            }

        } catch (Throwable e) {
            logger.log(Level.INFO, "handling exception");

            ValidationException ex = new AbstractExceptionUnwrapper<ValidationException>() {
            }.unwrap(e);

            if (ex != null) {
                Message msgs = new Message();
                msgs.setMessages(ex.getMessages());
                return Response.status(Status.NOT_ACCEPTABLE).entity(msgs).build();
            }

            logger.log(Level.INFO, "unhandled exception");
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PUT
    @Path("{username}/promote")
    @Auth("admin")
    public Response promoteUser(@PathParam("username") String username) {
        logger.log(Level.INFO, "promoteUser");
        us.promoteUser(username);
        return Response.status(Status.OK).build();
    }

    @PUT
    @Path("{username}/demote")
    @Auth("admin")
    public Response demoteUser(@PathParam("username") String username) {
        logger.log(Level.INFO, "demoteUser");

        if (username.equals(ac.getCallerPrincipal())) {
            return Response.status(Status.NOT_ACCEPTABLE).build();
        }

        us.demoteUser(username);
        return Response.status(Status.OK).build();
    }

    /**
     * For admins to edit user. the target is the path param username
     *
     * @param username
     * @param user
     * @return
     */
    @PUT
    @Path("{username}")
    @Auth("admin")
    public Response editUser(@PathParam("username") String username, User user) {
        logger.log(Level.INFO, "editUser");
        try {
            us.editUser(username, user.getPassword(), user.getEmail(), user.getFirstname(), user.getLastname(),
                    user.getPhonenumber(), user.getGender());
            return Response.status(Status.ACCEPTED).build();
        } catch (Throwable e) {
            logger.log(Level.INFO, "handling exception");

            ValidationException ex = new AbstractExceptionUnwrapper<ValidationException>() {
            }.unwrap(e);

            if (ex != null) {
                Message msgs = new Message();
                msgs.setMessages(ex.getMessages());
                return Response.status(Status.NOT_ACCEPTABLE).entity(msgs).build();
            }

            logger.log(Level.INFO, "unhandled exception");
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * for users to update their own profile
     *
     * @param user
     * @return
     */
    @PUT
    @Auth({"admin", "user"})
    public Response updateProfile(User user) {
        logger.log(Level.INFO, "updateProfile");
        try {
            us.editUser(ac.getCallerPrincipal(), user.getPassword(), user.getEmail(), user.getFirstname(),
                    user.getLastname(), user.getPhonenumber(), user.getGender());
            return Response.status(Status.ACCEPTED).build();
        } catch (Throwable e) {
            logger.log(Level.INFO, "handling exception");

            ValidationException ex = new AbstractExceptionUnwrapper<ValidationException>() {
            }.unwrap(e);

            if (ex != null) {
                Message msgs = new Message();
                msgs.setMessages(ex.getMessages());
                return Response.status(Status.NOT_ACCEPTABLE).entity(msgs).build();
            }

            logger.log(Level.INFO, "unhandled exception");
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DELETE
    @Auth("admin")
    @Path("{username}")
    public Response deleteUser(@PathParam("username") String username) {
        logger.log(Level.INFO, "deleteUser");

        logger.log(Level.INFO, "Caller: " + ac.getCallerPrincipal() + " - User: " + username);
        logger.log(Level.INFO, "Check self-deletion");
        if (ac.getCallerPrincipal().equals(username)) {
            logger.log(Level.INFO, "Self-deletion detected");
            return Response.status(Status.NOT_ACCEPTABLE).build();
        }
        logger.log(Level.INFO, "Passed self-deletion checking");

        us.deleteUserByUsername(username);
        return Response.status(Status.OK).build();

    }
}
