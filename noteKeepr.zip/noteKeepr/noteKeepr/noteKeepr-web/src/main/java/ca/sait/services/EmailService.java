/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.sait.services;

import java.util.Properties;
import java.util.concurrent.Future;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Singleton;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author 689626
 */
@Asynchronous
@Singleton
public class EmailService {

    private static final String EMAIL_ACCOUNT = "sait.test.web@gmail.com";
    private static final String EMAIL_PASSWORD = "web123456";

    public Future<Boolean> sendEmail(String email, String subject, String content) {
        try {
            Properties props = new Properties();
            props.put("mail.transport.protocol", "smtps");
            props.put("mail.smtps.host", "smtp.gmail.com");
            props.put("mail.smtps.port", 465);
            props.put("mail.smtps.auth", "true");
            props.put("mai.smtps.quitwait", "false");
            Session session = Session.getDefaultInstance(props);
            session.setDebug(true);

            Message message = new MimeMessage(session);
            message.setSubject(subject);

            Address fromAddress = new InternetAddress(EMAIL_ACCOUNT);
            Address toAddress = new InternetAddress(email);
            message.setFrom(fromAddress);
            message.setRecipient(Message.RecipientType.TO, toAddress);
            message.setText(content);
            Transport transport = session.getTransport();
            transport.connect(EMAIL_ACCOUNT, EMAIL_PASSWORD);
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();
            return new AsyncResult<>(true);
        } catch (MessagingException e) {
            return new AsyncResult<>(false);
        }
    }
}
