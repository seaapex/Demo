package ca.sait.unwrappers;

public interface ExceptionUnwrapper<T extends Throwable> {
	public T unwrap(Throwable t);
}
