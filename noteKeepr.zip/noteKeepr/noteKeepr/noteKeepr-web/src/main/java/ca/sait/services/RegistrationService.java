/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.sait.services;

import java.util.UUID;
import ca.sait.exceptions.ValidationException;
import ca.sait.unwrappers.AbstractExceptionUnwrapper;
import ca.sait.utils.EncryptionUtils;
import ca.sait.xml.Message;
import java.io.Serializable;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.TimeUnit;
import javax.ejb.EJB;
import javax.ejb.Stateful;
import javax.ejb.StatefulTimeout;

/**
 *
 * @author 689626
 */
@Stateful
@StatefulTimeout(unit = TimeUnit.MINUTES, value = 30)
public class RegistrationService implements Serializable {

    private String uuid, username, password;

    @EJB
    private UserService us;

    public Message holdUser(String username, String password, String email, String firstname, String lastname,
            String phonenumber, char gender) {

        this.uuid = UUID.randomUUID().toString();
        this.password = password;

        try {
            this.username = us.createUser(username, EncryptionUtils.encrypt(UUID.randomUUID().toString(), "SHA-256") /* no one can know the origin of this uuid */, email, firstname, lastname, phonenumber, gender);
        } catch (NoSuchAlgorithmException ex) {
            // This exception should never be thrown
        } catch (Throwable e) {

            ValidationException ex = new AbstractExceptionUnwrapper<ValidationException>() {
            }.unwrap(e);

            Message msgs = new Message();
            if (ex != null) {
                msgs.setMessages(ex.getMessages());
            } else {
                // Probably something duplicated in database
                String[] err = {"Username '" + username + "' is already exist"};
                msgs.setMessages(err);
            }
            return msgs;

        }

        // Stateful EJB would be discarded if it throws runtime exception, so just ignore
        return null;
    }

    public String getUUID() {
        return uuid;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}
